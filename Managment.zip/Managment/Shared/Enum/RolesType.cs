﻿namespace Management.Common.Enum
{
    public enum RolesType
    {
        HR,
        Admin,
        User
    }
}