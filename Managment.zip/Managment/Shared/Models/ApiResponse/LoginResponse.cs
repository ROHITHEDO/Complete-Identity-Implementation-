﻿namespace Management.Common.Models.ApiResponse
{
    public class LoginResponse : BaseResponse
    {
        public string Token { get; set; }
    }
}